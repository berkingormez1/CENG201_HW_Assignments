package BorrowQueue;

public class BorrowQueue {
	class Node {
        BorrowRequest data;
        Node next;
        Node(BorrowRequest r) {
            data = r;
            next = null;
        }
    }
    Node pHead = null; 
    Node pTail = null;
    Node nHead = null; 
    Node nTail = null;

    public void enqueue(BorrowRequest r) {
        Node node = new Node(r);
        if (r.priority) {
            if (pHead == null) {
                pHead = node;
                pTail = node;
            } else {
                pTail.next = node;
                pTail = node;
            }
        } else {
            if (nHead == null) {
                nHead = node;
                nTail = node;
            } else {
                nTail.next = node;
                nTail = node;
            }
        }
    }
    public BorrowRequest dequeue() {
        if (pHead != null) {
            BorrowRequest r = pHead.data;
            pHead = pHead.next;
            if (pHead == null) pTail = null;
            return r;
        }
        if (nHead != null) {
            BorrowRequest r = nHead.data;
            nHead = nHead.next;
            if (nHead == null) nTail = null;
            return r;
        }
        return null;
    }
    public void printQueue() {
        System.out.println("Priority requests:");
        Node tmp = pHead;
        while (tmp != null) {
            System.out.println("  " + tmp.data);
            tmp = tmp.next;
        }
        System.out.println("Normal requests:");
        tmp = nHead;
        while (tmp != null) {
            System.out.println("  " + tmp.data);
            tmp = tmp.next;
        }
    }
}


