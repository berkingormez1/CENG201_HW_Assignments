package BookList;

import java.awt.print.Book;

public class BookList {	
	    class Node {
	        Book book;
	        Node next;
	        Node(Book b) {
	            book = b;
	            next = null;
	        }
	    }

	    Node head = null;

	    public void addBook(Book b) {
	        Node newNode = new Node(b);
	        if (head == null) {
	            head = newNode;
	        } else {
	            Node tmp = head;
	            while (tmp.next != null) {
	                tmp = tmp.next;
	            }
	            tmp.next = newNode;
	        }
	    }

	    public void removeBook(int id) {
	        if (head == null) return;

	        if (head.book.id == id) {
	            head = head.next;
	            return;
	        }

	        Node tmp = head;
	        while (tmp.next != null) {
	            if (tmp.next.book.id == id) {
	                tmp.next = tmp.next.next;
	                break;
	            }
	            tmp = tmp.next;
	        }
	    }

	    public Book findBook(int id) {
	        Node tmp = head;
	        while (tmp != null) {
	            if (tmp.book.id == id) {
	                return tmp.book;
	            }
	            tmp = tmp.next;
	        }
	        return null;
	    }

	    public void printList() {
	        Node tmp = head;
	        while (tmp != null) {
	            System.out.println(tmp.book);
	            tmp = tmp.next;
	        }
	    }
	}



