package Book;
public class Book {
	int id;
    String title;
    String author;
    public Book(int i, String t, String a) {
        id = i;
        title = t;
        author = a;
    }
    public String toString() {
        return id + " - " + title + " - " + author;
    }
}


