package BorrowRequest;
public class BorrowRequest {
	int userId;
    int bookId;
    long requestTime;
    boolean priority;

    public BorrowRequest(int u, int b, boolean p) {
        userId = u;
        bookId = b;
        requestTime = System.currentTimeMillis();
        priority = p;
    }

    public String toString() {
        return userId + " wants book " + bookId + " priority=" + priority;
    }
}


