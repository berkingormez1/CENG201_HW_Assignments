package LibrarySystem;

public class LibrarySystem {
	BookList books = new BookList();
    BorrowQueue borrowQ = new BorrowQueue();
    ReturnStack returnS = new ReturnStack();

    public void addBook(Book b) {
        books.addBook(b);
    }

    public void addBorrow(BorrowRequest r) {
        borrowQ.enqueue(r);
    }

    public void addReturn(ReturnRequest r) {
        returnS.push(r);
    }

    public void processBorrow() {
        BorrowRequest br = borrowQ.dequeue();
        if (br != null) {
            // just simulate that it will be returned later
            returnS.push(new ReturnRequest(br.bookId));
        }
    }

    public void printState() {
        System.out.println("=== Books ===");
        books.printList();
        System.out.println("=== Borrow Requests ===");
        borrowQ.printQueue();
        System.out.println("=== Return Stack ===");
        returnS.printStack();
    }
}



