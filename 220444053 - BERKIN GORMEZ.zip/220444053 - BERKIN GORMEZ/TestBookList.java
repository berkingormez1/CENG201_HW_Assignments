package TestBookList;

import java.awt.print.Book;

public class TestBookList {
	public static void main(String[] args) {
        BookList list = new BookList();

        list.addBook(new Book(1, "Book1", "Author1"));
        list.addBook(new Book(2, "Book2", "Author2"));
        list.addBook(new Book(3, "Book3", "Author3"));
        list.addBook(new Book(4, "Book4", "Author4"));
        list.addBook(new Book(5, "Book5", "Author5"));

        list.removeBook(3);

        Book found = list.findBook(4);
        if (found != null) {
            System.out.println("Found: " + found);
        } else {
            System.out.println("Not found");
        }

        System.out.println("Final list:");
        list.printList();
    }
}


