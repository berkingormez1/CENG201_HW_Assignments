package ReturnRequest;
public class ReturnRequest {
	 int bookId;
	    long returnTime;

	    public ReturnRequest(int b) {
	        bookId = b;
	        returnTime = System.currentTimeMillis();
	    }

	    public String toString() {
	        return "Return book " + bookId + " at " + returnTime;
	    }
	}


