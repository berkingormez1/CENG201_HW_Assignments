package Main.java;
public class Main {
	public static void main(String[] args) throws InterruptedException {
        
        System.out.println("TASK 1:");
        BookList list = new BookList();
        list.addBook(new Book(1, "B1", "A1"));
        list.addBook(new Book(2, "B2", "A2"));
        list.addBook(new Book(3, "B3", "A3"));
        list.addBook(new Book(4, "B4", "A4"));
        list.addBook(new Book(5, "B5", "A5"));
        list.removeBook(3);
        Book found = list.findBook(4);
        System.out.println("Found: " + found);
        list.printList();

        
        System.out.println("\nTASK 2:");
        BorrowQueue bq = new BorrowQueue();
        for (int i = 1; i <= 10; i++) {
            boolean p = (i % 3 == 0);
            bq.enqueue(new BorrowRequest(100 + i, i, p));
            Thread.sleep(5);
        }
        bq.dequeue();
        bq.dequeue();
        bq.dequeue();
        bq.printQueue();
      
        System.out.println("\nTASK 3:");
        ReturnStack rs = new ReturnStack();
        rs.push(new ReturnRequest(1));
        rs.push(new ReturnRequest(2));
        rs.push(new ReturnRequest(3));
        rs.push(new ReturnRequest(4));
        rs.push(new ReturnRequest(5));
        rs.pop();
        rs.pop();
        rs.printStack();
     
        System.out.println("\nTASK 4:");
        LibrarySystem lib = new LibrarySystem();
        for (int i = 1; i <= 10; i++) {
            lib.addBook(new Book(i, "Book" + i, "Author" + i));
        }
        lib.addBorrow(new BorrowRequest(201, 2, false));
        lib.addBorrow(new BorrowRequest(202, 4, false));
        lib.addBorrow(new BorrowRequest(301, 1, true));
        lib.addBorrow(new BorrowRequest(302, 3, true));
        lib.addReturn(new ReturnRequest(9));
        lib.addReturn(new ReturnRequest(10));

        lib.printState();
        System.out.println("Processing 3 borrows...");
        lib.processBorrow();
        lib.processBorrow();
        lib.processBorrow();
        lib.printState();
    }
}


