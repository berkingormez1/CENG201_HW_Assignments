package ReturnStack;
public class ReturnStack {
	class Node {
        ReturnRequest data;
        Node next;
        Node(ReturnRequest r) {
            data = r;
            next = null;
        }
    }

    Node top = null;

    public void push(ReturnRequest r) {
        Node node = new Node(r);
        node.next = top;
        top = node;
    }

    public ReturnRequest pop() {
        if (top == null) return null;
        ReturnRequest r = top.data;
        top = top.next;
        return r;
    }

    public ReturnRequest peek() {
        if (top == null) return null;
        return top.data;
    }

    public void printStack() {
        Node tmp = top;
        while (tmp != null) {
            System.out.println(tmp.data);
            tmp = tmp.next;
        }
    }
}



